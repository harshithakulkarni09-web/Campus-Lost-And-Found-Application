import { Router }   from "express";
import { v4 as uuidv4 } from "uuid";
import multer        from "multer";
import { fileURLToPath } from "url";
import { dirname, join } from "path";
import { getDb }     from "../db.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname  = dirname(__filename);

/* ── Multer (image uploads) ── */
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, join(__dirname, "..", "uploads")),
  filename:    (req, file, cb) => cb(null, `${uuidv4()}.${file.originalname.split(".").pop()}`),
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ok = ["image/jpeg", "image/png", "image/gif", "image/webp"].includes(file.mimetype);
    cb(ok ? null : new Error("Images only (JPEG, PNG, GIF, WEBP)"), ok);
  },
});

const router = Router();

/* ── GET all items ── */
router.get("/", async (req, res) => {
  try {
    const db = await getDb();
    await db.read();
    res.json({ success: true, data: db.data.items || [] });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/* ── GET search (before /:id) ── */
router.get("/search", async (req, res) => {
  try {
    const db = await getDb();
    await db.read();
    const q     = (req.query.q || "").toLowerCase().trim();
    const items = db.data.items || [];

    const results = q
      ? items.filter(i =>
          [i.name, i.category, i.description, i.location, i.status, i.userName, i.userUSN]
            .some(f => (f || "").toLowerCase().includes(q))
        )
      : items;

    res.json({ success: true, data: results });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/* ── GET single item ── */
router.get("/:id", async (req, res) => {
  try {
    const db   = await getDb();
    await db.read();
    const item = (db.data.items || []).find(i => i.id === req.params.id);
    if (!item) return res.status(404).json({ success: false, error: "Item not found" });
    res.json({ success: true, data: item });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/* ── POST create item ──
   Saves user identity (userName, userUSN, userContact) from req.body.
────────────────────────────────────────────────────────────────────── */
router.post("/", upload.single("image"), async (req, res) => {
  try {
    const db = await getDb();
    await db.read();

    const { name, category, description, location, status,
            userName, userUSN, userContact } = req.body;

    if (!name || !status) {
      return res.status(400).json({ success: false, error: "name and status are required" });
    }

    const newItem = {
      id:          uuidv4(),
      name:        (name        || "").trim(),
      category:    (category    || "").trim(),
      description: (description || "").trim(),
      location:    (location    || "").trim(),
      status:      status === "found" ? "found" : "lost",
      image:       req.file ? `/uploads/${req.file.filename}` : "",
      // ── User identity ──
      userName:    (userName    || "").trim(),
      userUSN:     (userUSN     || "").trim().toUpperCase(),
      userContact: (userContact || "").trim(),
      createdAt:   new Date().toISOString(),
    };

    db.data.items.push(newItem);
    await db.write();
    res.status(201).json({ success: true, data: newItem });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/* ── PUT update item ──
   Ownership check: req.body.userUSN must match the stored userUSN.
────────────────────────────────────────────────────────────────────── */
router.put("/:id", upload.single("image"), async (req, res) => {
  try {
    const db    = await getDb();
    await db.read();
    const index = (db.data.items || []).findIndex(i => i.id === req.params.id);

    if (index === -1) {
      return res.status(404).json({ success: false, error: "Item not found" });
    }

    const existing = db.data.items[index];
    const requestingUSN = (req.body.userUSN || "").trim().toUpperCase();

    // Enforce ownership
    if (existing.userUSN && existing.userUSN !== requestingUSN) {
      return res.status(403).json({ success: false, error: "Not authorised to edit this item" });
    }

    const { name, category, description, location, status } = req.body;

    db.data.items[index] = {
      ...existing,
      name:        (name        !== undefined ? name        : existing.name        || "").trim(),
      category:    (category    !== undefined ? category    : existing.category    || "").trim(),
      description: (description !== undefined ? description : existing.description || "").trim(),
      location:    (location    !== undefined ? location    : existing.location    || "").trim(),
      status:      status === "found" ? "found" : status === "lost" ? "lost" : existing.status,
      image:       req.file ? `/uploads/${req.file.filename}` : existing.image,
      updatedAt:   new Date().toISOString(),
    };

    await db.write();
    res.json({ success: true, data: db.data.items[index] });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/* ── DELETE item ──
   Ownership check: req.body.userUSN must match the stored userUSN.
────────────────────────────────────────────────────────────────────── */
router.delete("/:id", async (req, res) => {
  try {
    const db    = await getDb();
    await db.read();
    const index = (db.data.items || []).findIndex(i => i.id === req.params.id);

    if (index === -1) {
      return res.status(404).json({ success: false, error: "Item not found" });
    }

    const existing      = db.data.items[index];
    const requestingUSN = (req.body.userUSN || "").trim().toUpperCase();

    // Enforce ownership
    if (existing.userUSN && existing.userUSN !== requestingUSN) {
      return res.status(403).json({ success: false, error: "Not authorised to delete this item" });
    }

    const deleted = db.data.items.splice(index, 1)[0];
    await db.write();
    res.json({ success: true, data: deleted });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

export default router;
