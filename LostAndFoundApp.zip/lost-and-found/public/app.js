/* ══════════════════════════════════════════════════════════
   CAMPUS LOST & FOUND — app.js
   ══════════════════════════════════════════════════════════
   Sections:
     1. Auth — read / guard / logout
     2. State & DOM refs
     3. API helpers
     4. Load & render items
     5. Build item card (ownership-aware)
     6. Add / Edit modal
     7. File image preview
     8. Form submit (attaches user identity)
     9. Delete (ownership-checked)
    10. Contact Owner modal
    11. Filter tabs & search
    12. Campus Map (slide + markers)
    13. Utilities (toast, escHtml, highlight)
══════════════════════════════════════════════════════════ */


/* ── 1. AUTH ─────────────────────────────────────────────
   currentUser is loaded from localStorage.
   If not present, redirect to login page.
──────────────────────────────────────────────────────── */
const currentUser = (() => {
  try { return JSON.parse(localStorage.getItem('lf_user')); } catch { return null; }
})();

if (!currentUser) {
  window.location.replace('/login.html');
  throw new Error('not logged in');       // stop script execution
}

// Show user name in header
document.getElementById('user-avatar').textContent      = currentUser.name[0].toUpperCase();
document.getElementById('user-name-display').textContent = currentUser.name;

document.getElementById('logout-btn').addEventListener('click', () => {
  localStorage.removeItem('lf_user');
  window.location.replace('/login.html');
});


/* ── 2. STATE & DOM REFS ─────────────────────────────── */
const API_BASE = '/api/items';

let allItems        = [];
let activeFilter    = 'all';
let searchQuery     = '';
let pendingDeleteId = null;

const itemsContainer  = document.getElementById('items-container');
const searchInput     = document.getElementById('search-input');
const openModalBtn    = document.getElementById('open-modal-btn');
const modalBackdrop   = document.getElementById('modal-backdrop');
const modalCloseBtn   = document.getElementById('modal-close-btn');
const cancelBtn       = document.getElementById('cancel-btn');
const itemForm        = document.getElementById('item-form');
const editIdField     = document.getElementById('edit-id');
const modalTitle      = document.getElementById('modal-title');
const submitLabel     = document.getElementById('submit-label');
const submitBtn       = document.getElementById('submit-btn');
const filterRow       = document.getElementById('filter-row');
const confirmBackdrop = document.getElementById('confirm-backdrop');
const confirmCancel   = document.getElementById('confirm-cancel');
const confirmDelete   = document.getElementById('confirm-delete');
const toastContainer  = document.getElementById('toast-container');
const contactBackdrop = document.getElementById('contact-backdrop');
const contactCloseBtn = document.getElementById('contact-close-btn');
const contactContent  = document.getElementById('contact-content');

const statTotal = document.getElementById('stat-total');
const statLost  = document.getElementById('stat-lost');
const statFound = document.getElementById('stat-found');

const fieldName        = document.getElementById('field-name');
const fieldStatus      = document.getElementById('field-status');
const fieldCategory    = document.getElementById('field-category');
const fieldLocation    = document.getElementById('field-location');
const fieldDescription = document.getElementById('field-description');
const fieldImage       = document.getElementById('field-image');
const existingImage    = document.getElementById('existing-image');
const fileLabel        = document.getElementById('file-label');
const imagePreviewWrap = document.getElementById('image-preview-wrap');
const imagePreview     = document.getElementById('image-preview');
const clearImageBtn    = document.getElementById('clear-image-btn');


/* ── 3. API HELPERS ──────────────────────────────────── */
async function apiFetch(path, options = {}) {
  const isFormData = options.body instanceof FormData;
  const res = await fetch(API_BASE + path, {
    ...options,
    headers: isFormData ? {} : { 'Content-Type': 'application/json', ...(options.headers || {}) },
  });
  const json = await res.json();
  if (!json.success) throw new Error(json.error || 'Request failed');
  return json.data;
}


/* ── 4. LOAD & RENDER ────────────────────────────────── */
async function loadItems() {
  try {
    allItems = await apiFetch('');
    if (!Array.isArray(allItems)) allItems = [];
    renderAll();
  } catch (err) {
    showToast('Failed to load items: ' + err.message, 'error');
    itemsContainer.innerHTML = emptyState('⚠️', 'Error loading items', err.message);
  }
}

async function searchItems(q) {
  try {
    const data = await apiFetch('/search?q=' + encodeURIComponent(q.trim()));
    allItems = Array.isArray(data) ? data : [];
    renderAll();
  } catch (err) {
    showToast('Search failed: ' + err.message, 'error');
  }
}

function renderAll() {
  // Update stats (always on full set)
  statTotal.textContent = allItems.length;
  statLost.textContent  = allItems.filter(i => i.status === 'lost').length;
  statFound.textContent = allItems.filter(i => i.status === 'found').length;

  let items = allItems;
  if (activeFilter !== 'all') items = items.filter(i => i.status === activeFilter);

  if (!items.length) {
    const icon = activeFilter === 'lost' ? '🔴' : activeFilter === 'found' ? '🟢' : '📭';
    const msg  = searchQuery ? 'No items match your search' : 'Nothing reported yet';
    const sub  = searchQuery ? 'Try different keywords' : 'Click "Report" to add the first item';
    itemsContainer.innerHTML = emptyState(icon, msg, sub);
    return;
  }

  itemsContainer.innerHTML = items.map(buildCard).join('');
  attachCardListeners();
}


/* ── 5. BUILD ITEM CARD ──────────────────────────────────
   Shows edit/delete only to the item's owner.
   Shows "Contact Owner" to everyone else.
──────────────────────────────────────────────────────── */
function buildCard(item) {
  const id       = item.id || '';
  const name     = escHtml(item.name || 'Unnamed');
  const status   = item.status === 'found' ? 'found' : 'lost';
  const category = escHtml(item.category || '');
  const location = escHtml(item.location || '');
  const desc     = escHtml(item.description || '');
  const image    = item.image || '';
  const owner    = escHtml(item.userName  || 'Unknown');
  const ownerUsn = escHtml(item.userUSN   || '');
  const contact  = item.userContact || '';
  const date     = item.createdAt
    ? new Date(item.createdAt).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })
    : '';

  const isOwner  = currentUser && item.userUSN === currentUser.usn;

  const imgHtml = image
    ? `<img class="item-image" src="${escHtml(image)}" alt="${name}" loading="lazy"
          onerror="this.style.display='none';this.nextElementSibling.style.display='flex';">
       <div class="item-image-placeholder" style="display:none;">${status === 'lost' ? '😢' : '🎉'}</div>`
    : `<div class="item-image-placeholder">${status === 'lost' ? '😢' : '🎉'}</div>`;

  // Owner actions (edit + delete) vs Contact button
  const ownerActions = isOwner
    ? `<button class="btn btn-ghost btn-sm edit-btn"   data-id="${id}">✏️ Edit</button>
       <button class="btn btn-danger btn-sm delete-btn" data-id="${id}">🗑️ Delete</button>`
    : `<button class="btn btn-contact btn-sm contact-btn" data-id="${id}">💬 Contact</button>`;

  return `
    <div class="item-card" data-id="${id}">
      ${imgHtml}
      <div class="item-body">
        <div class="item-header">
          <span class="item-name">${name}</span>
          <span class="badge badge-${status}">${status}</span>
        </div>
        <div class="item-meta">
          ${category ? `<span>🏷️ ${category}</span>` : ''}
          ${location ? `<span>📍 ${location}</span>` : ''}
          ${date     ? `<span>🗓️ ${date}</span>` : ''}
        </div>
        ${desc ? `<p class="item-desc">${desc}</p>` : ''}
        <div class="item-owner">
          <span class="owner-avatar">${owner[0]?.toUpperCase() || '?'}</span>
          <span class="owner-info">
            <span class="owner-name">${owner}</span>
            ${ownerUsn ? `<span class="owner-usn">${ownerUsn}</span>` : ''}
          </span>
        </div>
      </div>
      <div class="item-footer">
        ${ownerActions}
      </div>
    </div>`;
}

function attachCardListeners() {
  itemsContainer.querySelectorAll('.edit-btn').forEach(btn =>
    btn.addEventListener('click', () => openEditModal(btn.dataset.id))
  );
  itemsContainer.querySelectorAll('.delete-btn').forEach(btn =>
    btn.addEventListener('click', () => openConfirm(btn.dataset.id))
  );
  itemsContainer.querySelectorAll('.contact-btn').forEach(btn =>
    btn.addEventListener('click', () => openContactModal(btn.dataset.id))
  );
}

function emptyState(icon, heading, sub) {
  return `<div class="empty-state">
    <div class="empty-icon">${icon}</div>
    <h3>${heading}</h3><p>${sub}</p>
  </div>`;
}


/* ── 6. ADD / EDIT MODAL ────────────────────────────── */
function openAddModal() {
  editIdField.value    = '';
  itemForm.reset();
  resetImageField();
  modalTitle.textContent  = 'Report Item';
  submitLabel.textContent = 'Add Item';
  submitBtn.innerHTML = `<svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg> Add Item`;
  openModal(modalBackdrop);
}

function openEditModal(id) {
  const item = allItems.find(i => i.id === id);
  if (!item) return showToast('Item not found', 'error');

  editIdField.value        = item.id;
  fieldName.value          = item.name || '';
  fieldStatus.value        = item.status === 'found' ? 'found' : 'lost';
  fieldCategory.value      = item.category || '';
  fieldLocation.value      = item.location || '';
  fieldDescription.value   = item.description || '';
  existingImage.value      = item.image || '';
  resetImageField();

  if (item.image) {
    imagePreview.src              = item.image;
    imagePreviewWrap.style.display = 'block';
    fileLabel.textContent         = 'Replace image…';
  }

  modalTitle.textContent  = 'Edit Item';
  submitLabel.textContent = 'Save Changes';
  submitBtn.innerHTML = `<svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M5 13l4 4L19 7"/></svg> Save Changes`;
  openModal(modalBackdrop);
}

function openModal(el) {
  el.classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  modalBackdrop.classList.remove('open');
  document.body.style.overflow = '';
  itemForm.reset();
  editIdField.value = '';
  resetImageField();
}


/* ── 7. FILE IMAGE PREVIEW ───────────────────────────── */
fieldImage.addEventListener('change', () => {
  const file = fieldImage.files[0];
  if (!file) return;
  fileLabel.textContent         = file.name;
  imagePreview.src              = URL.createObjectURL(file);
  imagePreviewWrap.style.display = 'block';
});

clearImageBtn.addEventListener('click', () => {
  resetImageField();
  existingImage.value = '';
});

function resetImageField() {
  fieldImage.value              = '';
  imagePreview.src              = '';
  imagePreviewWrap.style.display = 'none';
  fileLabel.textContent         = 'Choose image…';
}


/* ── 8. FORM SUBMIT ──────────────────────────────────────
   Attaches userName, userUSN, userContact from currentUser.
   Sends as FormData so the image file is included.
──────────────────────────────────────────────────────── */
itemForm.addEventListener('submit', async e => {
  e.preventDefault();

  const name = fieldName.value.trim();
  if (!name) { showToast('Item name is required', 'error'); fieldName.focus(); return; }

  const formData = new FormData();
  formData.append('name',        name);
  formData.append('status',      fieldStatus.value);
  formData.append('category',    fieldCategory.value);
  formData.append('location',    fieldLocation.value.trim());
  formData.append('description', fieldDescription.value.trim());

  // Attach user identity
  formData.append('userName',    currentUser.name);
  formData.append('userUSN',     currentUser.usn);
  formData.append('userContact', currentUser.contact || '');

  if (fieldImage.files[0]) formData.append('image', fieldImage.files[0]);

  const id = editIdField.value;
  submitBtn.disabled = true;

  try {
    if (id) {
      const updated = await apiFetch('/' + id, { method: 'PUT', body: formData });
      const idx = allItems.findIndex(i => i.id === id);
      if (idx !== -1) allItems[idx] = updated;
      showToast('Item updated!', 'success');
    } else {
      const created = await apiFetch('', { method: 'POST', body: formData });
      allItems.unshift(created);
      showToast('Item reported!', 'success');
    }
    closeModal();
    renderAll();
  } catch (err) {
    showToast('Error: ' + err.message, 'error');
  } finally {
    submitBtn.disabled = false;
  }
});


/* ── 9. DELETE ───────────────────────────────────────────
   Backend also enforces ownership, but we gate the UI too.
──────────────────────────────────────────────────────── */
function openConfirm(id) {
  pendingDeleteId = id;
  confirmBackdrop.classList.add('open');
}

function closeConfirm() {
  pendingDeleteId = null;
  confirmBackdrop.classList.remove('open');
}

confirmCancel.addEventListener('click', closeConfirm);

confirmDelete.addEventListener('click', async () => {
  if (!pendingDeleteId) return;
  const id = pendingDeleteId;
  closeConfirm();
  try {
    // Send USN so backend can verify ownership
    await apiFetch('/' + id, {
      method: 'DELETE',
      body: JSON.stringify({ userUSN: currentUser.usn }),
    });
    allItems = allItems.filter(i => i.id !== id);
    renderAll();
    showToast('Item deleted', 'info');
  } catch (err) {
    showToast('Delete failed: ' + err.message, 'error');
  }
});


/* ── 10. CONTACT OWNER MODAL ─────────────────────────────
   Shows owner name, USN, and contact info.
   If contact is an email → renders a mailto button.
   If contact is a phone  → renders a tel link.
   Otherwise shows a copy-able text field.
──────────────────────────────────────────────────────── */
function openContactModal(id) {
  const item = allItems.find(i => i.id === id);
  if (!item) return;

  const name    = escHtml(item.userName    || 'Unknown');
  const usn     = escHtml(item.userUSN     || '—');
  const contact = (item.userContact || '').trim();
  const itemName = escHtml(item.name || 'this item');

  let contactHtml = '';

  if (contact) {
    const isEmail = contact.includes('@');
    const isPhone = /^[+\d][\d\s\-()]{6,}$/.test(contact);

    if (isEmail) {
      const mailto = `mailto:${encodeURIComponent(contact)}?subject=${encodeURIComponent('Regarding your ' + (item.status === 'lost' ? 'lost' : 'found') + ' item: ' + (item.name || ''))}`;
      contactHtml = `
        <p class="contact-label">Email</p>
        <p class="contact-value">${escHtml(contact)}</p>
        <a href="${mailto}" class="btn btn-primary contact-action-btn">
          <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" viewBox="0 0 24 24">
            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
            <polyline points="22,6 12,12 2,6"/>
          </svg>
          Send Email
        </a>`;
    } else if (isPhone) {
      contactHtml = `
        <p class="contact-label">Phone</p>
        <p class="contact-value">${escHtml(contact)}</p>
        <a href="tel:${encodeURIComponent(contact)}" class="btn btn-primary contact-action-btn">
          <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" viewBox="0 0 24 24">
            <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 13a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.6 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 9.91a16 16 0 0 0 6.16 6.16l.97-.88a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/>
          </svg>
          Call
        </a>`;
    } else {
      contactHtml = `
        <p class="contact-label">Contact</p>
        <p class="contact-value">${escHtml(contact)}</p>`;
    }
  } else {
    contactHtml = `<p class="contact-no-info">This user hasn't shared contact information.</p>`;
  }

  contactContent.innerHTML = `
    <div class="contact-owner-card">
      <div class="contact-owner-avatar">${name[0]?.toUpperCase() || '?'}</div>
      <div class="contact-owner-details">
        <p class="contact-owner-name">${name}</p>
        <p class="contact-owner-usn">${usn}</p>
      </div>
    </div>
    <div class="contact-item-ref">Regarding: <strong>${itemName}</strong> <span class="badge badge-${item.status === 'found' ? 'found' : 'lost'}" style="font-size:.7rem;">${item.status}</span></div>
    <div class="contact-section">${contactHtml}</div>`;

  openModal(contactBackdrop);
}

contactCloseBtn.addEventListener('click', () => {
  contactBackdrop.classList.remove('open');
  document.body.style.overflow = '';
});

contactBackdrop.addEventListener('click', e => {
  if (e.target === contactBackdrop) {
    contactBackdrop.classList.remove('open');
    document.body.style.overflow = '';
  }
});


/* ── 11. FILTERS & SEARCH ───────────────────────────── */
filterRow.addEventListener('click', e => {
  const tab = e.target.closest('.filter-tab');
  if (!tab) return;
  filterRow.querySelectorAll('.filter-tab').forEach(t => t.classList.remove('active'));
  tab.classList.add('active');
  activeFilter = tab.dataset.filter || 'all';
  renderAll();
});

let searchTimer;
searchInput.addEventListener('input', () => {
  clearTimeout(searchTimer);
  const q = searchInput.value.trim();
  searchQuery = q;
  searchTimer = setTimeout(() => { q ? searchItems(q) : loadItems(); }, 280);
});

// Modal open/close events
openModalBtn.addEventListener('click', openAddModal);
modalCloseBtn.addEventListener('click', closeModal);
cancelBtn.addEventListener('click', closeModal);
modalBackdrop.addEventListener('click', e => { if (e.target === modalBackdrop) closeModal(); });
confirmBackdrop.addEventListener('click', e => { if (e.target === confirmBackdrop) closeConfirm(); });

document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { closeModal(); closeConfirm(); }
});


/* ── 12. CAMPUS MAP ──────────────────────────────────────
   Location → coordinate map (% of image dimensions).
   Based on New Horizon College of Engineering satellite map.
──────────────────────────────────────────────────────── */
const CAMPUS_LOCATIONS = {
  'sports ground':  { x: 65, y: 22 },
  'gate 3':         { x: 34, y: 11 },
  'sports gate':    { x: 34, y: 11 },
  'open stage':     { x: 55, y: 34 },
  'seminar hall':   { x: 52, y: 44 },
  'falconry':       { x: 52, y: 44 },
  'mba classrooms': { x: 42, y: 53 },
  'mba block':      { x: 42, y: 53 },
  'gate 1':         { x: 20, y: 48 },
  'main gate':      { x: 20, y: 48 },
  'quadrangle':     { x: 74, y: 38 },
  'umbrella':       { x: 74, y: 46 },
  'nirvana':        { x: 82, y: 51 },
  'tejas':          { x: 83, y: 31 },
  'library':        { x: 67, y: 70 },
  'auditorium':     { x: 67, y: 70 },
  'vc room':        { x: 67, y: 70 },
  'chanakya hall':  { x: 47, y: 80 },
  'chanakya':       { x: 47, y: 80 },
};

function matchLocation(text) {
  if (!text) return null;
  const lower = text.toLowerCase().trim();
  if (CAMPUS_LOCATIONS[lower]) return CAMPUS_LOCATIONS[lower];
  for (const [key, coords] of Object.entries(CAMPUS_LOCATIONS)) {
    if (lower.includes(key) || key.includes(lower)) return coords;
  }
  return null;
}

const pagesWrapper = document.getElementById('pages-wrapper');
const goToMapBtn   = document.getElementById('go-to-map');
const backBtn      = document.getElementById('back-btn');
const markersLayer = document.getElementById('markers-layer');
const mapTooltip   = document.getElementById('map-tooltip');

function openMap()  {
  pagesWrapper.classList.add('map-open');
  goToMapBtn.classList.add('hidden');
  renderMapMarkers();
}
function closeMap() {
  pagesWrapper.classList.remove('map-open');
  goToMapBtn.classList.remove('hidden');
}

goToMapBtn.addEventListener('click', openMap);
backBtn.addEventListener('click', closeMap);

async function renderMapMarkers() {
  markersLayer.innerHTML = '';
  let items;
  try { items = await apiFetch(''); } catch { return; }

  items.forEach(item => {
    const coords = matchLocation(item.location);
    if (!coords) return;

    const marker = document.createElement('div');
    marker.className = `map-marker ${item.status === 'found' ? 'marker-found' : 'marker-lost'}`;
    marker.style.left = coords.x + '%';
    marker.style.top  = coords.y + '%';

    marker.addEventListener('mouseenter', e => {
      mapTooltip.innerHTML = `<strong>${escHtml(item.name)}</strong><br>${item.status === 'lost' ? '🔴 Lost' : '🟢 Found'} · ${escHtml(item.location || '')}`;
      mapTooltip.classList.add('visible');
      positionTooltip(e);
    });
    marker.addEventListener('mousemove', positionTooltip);
    marker.addEventListener('mouseleave', () => mapTooltip.classList.remove('visible'));
    marker.addEventListener('click', () => {
      closeMap();
      setTimeout(() => highlightCard(item.id), 480);
    });

    markersLayer.appendChild(marker);
  });
}

function positionTooltip(e) {
  const rect = document.getElementById('map-container').getBoundingClientRect();
  let x = e.clientX - rect.left + 14;
  let y = e.clientY - rect.top  - 40;
  if (x + 210 > rect.width)  x = e.clientX - rect.left - 215;
  if (y < 0) y = e.clientY - rect.top + 14;
  mapTooltip.style.left = x + 'px';
  mapTooltip.style.top  = y + 'px';
}


/* ── 13. UTILITIES ───────────────────────────────────── */
function highlightCard(id) {
  const card = document.querySelector(`.item-card[data-id="${id}"]`);
  if (!card) return;
  card.scrollIntoView({ behavior: 'smooth', block: 'center' });
  card.classList.add('card-highlight');
  setTimeout(() => card.classList.remove('card-highlight'), 2200);
}

function showToast(message, type = 'info') {
  const icons = { success: '✅', error: '❌', info: 'ℹ️' };
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `<span>${icons[type]}</span><span>${escHtml(message)}</span>`;
  toastContainer.appendChild(toast);
  setTimeout(() => toast.remove(), 3000);
}

function escHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

/* ── Init ── */
loadItems();
